import React from 'react';
import TrainerDashboard from '../../components/trainer/TrainerDashboard';

const TrainerDashboardPage = () => {
  console.log('🔍 TrainerDashboardPage is rendering');
  return <TrainerDashboard />;
};

export default TrainerDashboardPage;