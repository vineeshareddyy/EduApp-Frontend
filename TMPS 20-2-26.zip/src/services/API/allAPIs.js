// // src/services/API/allAPIs.js
// // Central export file for all API modules

// // Export all API modules
// export { courseDocumentsAPI } from './courseDocuments';
// export { sessionrecordings } from './sessionrecordings';
// // export { trainerTasksAPI } from './trainerTasks';
// // export { mockInterviewsAPI } from './mockInterviews';
// // export { dailyStandupsAPI } from './dailyStandups';
// // export { mockTestsAPI } from './mockTests';
// // export { studentResultsAPI } from './studentResults';
// // export { sessionsAPI } from './sessions';
// // export { testCompilationAPI } from './testCompilation';
// // export { taskSubmissionsAPI } from './taskSubmissions';

// // // Export utility functions
// // export { apiRequest, createFormData, API_BASE_URL } from './index';